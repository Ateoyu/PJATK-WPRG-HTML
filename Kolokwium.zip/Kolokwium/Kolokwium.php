<?php

require_once "Movie.php";

$errorMessage = null;

if (!isset($_SESSION)) {
    session_start();
}
function toArray(): array {
    $file = fopen("movies.csv", "r");
    if ($file !== FALSE) {
        $movies = [];
        fgetcsv($file);
        while (($data = fgetcsv($file, 1000)) !== FALSE) {
            if (count($data) == 6) {
                $nextMovie = new Movie($data[0], $data[1], $data[2], intval($data[3]), $data[4], floatval($data[5]));
                $movies[] = $nextMovie;
            } else {
                echo "Error in data format";
                fclose($file);
                return [];
            }
        }
        fclose($file);
        return $movies;
    } else {
        echo "Error in opening file";
        return [];
    }
}
$movies = toArray();
$_SESSION["movies"] = $movies;

function sortByReleaseDateAsc($a, $b): int {
    if ($a->getReleaseYear() == $b->getReleaseYear()) {
        return 0;
    }
    return ($a->getReleaseYear() < $b->getReleaseYear()) ? -1 : 1;
}

function sortByReleaseDateDesc($a, $b): int {
    if ($a->getReleaseYear() == $b->getReleaseYear()) {
        return 0;
    }
    return ($a->getReleaseYear() > $b->getReleaseYear()) ? -1 : 1;
}

function sortByRatingAsc($a, $b):int {
if ($a->getRating() == $b->getRating()) {
        return 0;
    }
    return ($a->getRating() < $b->getRating()) ? -1 : 1;
}

function sortByRatingDesc($a, $b):int {
    if ($a->getRating() == $b->getRating()) {
        return 0;
    }
    return ($a->getRating() > $b->getRating()) ? -1 : 1;
}

if (isset($_POST['releaseDateSortAscending'])) {
    usort($_SESSION['movies'], "sortByReleaseDateAsc");
}

if (isset($_POST['releaseDateSortDescending'])) {
    usort($_SESSION['movies'], "sortByReleaseDateDesc");
}

if (isset($_POST['ratingSortAscending'])) {
    usort($_SESSION['movies'], "sortByRatingAsc");
}

if (isset($_POST['ratingSortDescending'])) {
    usort($_SESSION['movies'], "sortByRatingDesc");
}

if (isset($_POST['addMovie'])) {
    $newMovie = new Movie($_POST['id'], $_POST['title'], $_POST['director'], $_POST['releaseYear'], $_POST['genre'], $_POST['rating']);
    $newMovieArr = array($_POST['id'], $_POST['title'], $_POST['director'], $_POST['releaseYear'], $_POST['genre'], $_POST['rating']);

    $isInputCorrect = true;

    foreach ($newMovieArr as $movieProperty) {
        if (empty($movieProperty)) {
            $errorMessage = "Movie property cannot be empty";
            $isInputCorrect = false;
        }
    }

    foreach ($movies as $movie) {
        if ($movie->getId() == $newMovie->getId()) {
            $errorMessage = "Movie ID already exists, input a new ID";
            $isInputCorrect = false;
        }
    }

    if (!is_numeric($newMovie->getId()) || !is_numeric($newMovie->getReleaseYear()) || !is_numeric($newMovie->getRating())) {
        $errorMessage = "Error in data format, Please make sure that ID, Release Year and Rating are numbers.";
        $isInputCorrect = false;
    }

    if ($isInputCorrect) {
        $_SESSION['movies'][] = $newMovie;
    }

    function submitEditMovie(): void {
        $editID = $_POST['id'];
        $editTitle = $_POST['title'];
        $editDirector = $_POST['director'];
        $editReleaseYear = $_POST['releaseYear'];
        $editGenre = $_POST['genre'];
        $editRating = $_POST['rating'];
        
        $movieIndex = array_search($editID, array_column($_SESSION['movies'], 'id'));
        
        $_SESSION['movies'][$movieIndex]->setTitle($editTitle);
        $_SESSION['movies'][$movieIndex]->setDirector($editDirector);
        $_SESSION['movies'][$movieIndex]->setReleaseYear($editReleaseYear);
        $_SESSION['movies'][$movieIndex]->setGenre($editGenre);
        $_SESSION['movies'][$movieIndex]->setRating($editRating);
    }

    if (isset($_POST['submitEditMovie'])) {
        submitEditMovie();
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Kolokwium</title>
<link rel="stylesheet" href="Kolokwium.css">
</head>
<body>

<header>
    <h1>Movies Database</h1>
</header>

<div class="tableSortOptions">
    <form method="POST" action="">
        <input type="hidden" value="1">
        <button type="submit" name="releaseDateSortAscending">Sort Release Date (Ascending)</button>
    </form>
    <form method="POST" action="">
        <input type="hidden" value="2">
        <button type="submit" name="releaseDateSortDescending">Sort Release Date (Descending)</button>
    </form>
    <form method="POST" action="">
        <input type="hidden" value="3">
        <button type="submit" name="ratingSortAscending">Sort Rating (Ascending)</button>
    </form>
    <form method="POST" action="">
        <input type="hidden" value="4">
        <button type="submit" name="ratingSortDescending">Sort Rating (Descending)</button>
    </form>
</div>
<div class="table">
<table>
    <thead>
    <tr>
        <?php
        $headers = $movies[0];
        foreach ($headers as $header=>$value) {
            echo "<th>" . $header . "</th>";
        }
        ?>
    </tr>
    </thead>
    <tbody>
        <?php 
            foreach ($_SESSION['movies'] as $movie) {
                echo "<tr>";
                echo "<td>" . $movie->getID() . "</td>";
                echo "<td>" . $movie->getTitle() . "</td>";
                echo "<td>" . $movie->getDirector() . "</td>";
                echo "<td>" . $movie->getReleaseYear() . "</td>";
                echo "<td>" . $movie->getGenre() . "</td>";
                echo "<td>" . $movie->getRating() . "</td>";
                echo "<form method='POST' action=''> <td><button type='submit' name='editMovie' value='" . $movie->getID() . "'>Edit</button></td></form>";
                echo "</tr>";
            }
        ?>
    </tbody>
</table>
</div>

<form method="POST" action="">
    <fieldset>
        <legend>Add a new movie</legend>
        <label for="id">ID:</label>
        <input type="number" id="id" name="id" required>
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>
        <label for="director">Director:</label>
        <input type="text" id="director" name="director" required>
        <label for="releaseYear">Release Year:</label>
        <input type="number" id="releaseYear" name="releaseYear" required>
        <label for="genre">Genre:</label>
        <input type="text" id="genre" name="genre" required>
        <label for="rating">Rating:</label>
        <input type="number" id="rating" name="rating" required>
        <button type="submit" name="addMovie">Add movie</button>
    </fieldset>
    <?php
    if (!empty($errorMessage)) {
        echo "<p>" . $errorMessage . "</p>";
    }
    ?>
</form>

    <?php 
    if (isset($_POST['editMovie'])) {
        $movieToEdit = $_POST['editMovie'];
        $movieIndex = array_search($movieToEdit, array_column($_SESSION['movies'], 'id'));
        $movie = $_SESSION['movies'][$movieIndex];
        ?>
    <form method='POST' action=''>
    <fieldset>
        <legend>Edit movie</legend>
        <label for='id'>ID:</label>
        <input type='number' id='id' name='id' value='<?= $movie->getId() ?>' required>
        <label for='title'>Title:</label>
        <input type='text' id='title' name='title' value='<?= $movie->getTitle() ?>' required>
        <label for='director'>Director:</label>
        <input type='text' id='director' name='director' value='<?= $movie->getDirector() ?>' required>
        <label for='releaseYear'>Release Year:</label>
        <input type='number' id='releaseYear' name='releaseYear' value='<?= $movie->getReleaseYear() ?>' required>
        <label for='genre'>Genre:</label>
        <input type='text' id='genre' name='genre' value='<?= $movie->getGenre() ?>' required>
        <label for='rating'>Rating:</label>
        <input type='number' id='rating' name='rating' step="any" value='<?= $movie->getRating() ?>' required>
        <button type='submit' name='submitEditMovie'>Edit movie</button>
        </fieldset>
        </form>
    <?php } ?>
    
</body>
</html>